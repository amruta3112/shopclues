package searchProduct;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.RegistrationRepo;
import repository.SearchProduct;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class searchTest 
{
	WebDriver driver;
	
  @BeforeTest
   public void beforeTest() throws InterruptedException 
   {
	     WebDriverManager.chromedriver().setup();
		 driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 Thread.sleep(2000);
		
   }
  @Test
  public void f() throws InterruptedException
  {
	 SearchProduct s=new  SearchProduct ();
	 
	 SearchProduct.url(driver);
	 Thread.sleep(3000);
	 SearchProduct.search(driver);
	 Thread.sleep(50000);
	 SearchProduct.clickonsearch(driver);
	 Thread.sleep(5000);
  }
  

  @AfterTest
  public void afterTest()
  {
	  driver.close();
  }

}
