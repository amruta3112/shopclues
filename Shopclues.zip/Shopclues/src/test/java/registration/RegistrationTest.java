package registration;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.RegistrationRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class RegistrationTest
{
	WebDriver driver;
 @BeforeTest
 public void beforeTest() throws InterruptedException
 {
	 WebDriverManager.chromedriver().setup();
	 driver=new ChromeDriver();
	 driver.manage().window().maximize();
	 Thread.sleep(2000);
	 
 }
  @Test
  public void registration() throws InterruptedException, IOException 
  {
	  
	  FileInputStream file=new   FileInputStream("data/Automation project.xlsx");
	  XSSFWorkbook w=new  XSSFWorkbook(file);
	  XSSFSheet s=w.getSheet("Automation project");
	  int rowsize=s.getLastRowNum();
	  System.out.println("no of email id and mobile number:"+rowsize);
	  RegistrationRepo r=new RegistrationRepo();
	  
	  RegistrationRepo.url(driver);
	  
	  for(int i=1; i<=rowsize; i++)
	  {
		  String emailid=s.getRow(i).getCell(0).getStringCellValue();
		  String mobilenumber=s.getRow(i).getCell(1).getStringCellValue();
		  System.out.println(emailid+"\t\t"+mobilenumber);
	  
	  
	  RegistrationRepo.clickonRegister(driver).click(); 
	  Thread.sleep(2000);
	  //Actions act=new Actions(driver);
	  //act.moveToElement( RegistrationRepo.enteremailid(driver)).click().sendKeys(emailid).build().perform();
	  
	  RegistrationRepo.enteremailid(driver).sendKeys(emailid);
	  Thread.sleep(2000);
	  RegistrationRepo.entermobilenumber(driver).sendKeys(mobilenumber);
	  Thread.sleep(2000);
	  RegistrationRepo.clickonregisterbutton(driver).click();
	  Thread.sleep(2000);
	  
	  RegistrationRepo.enteremailid(driver).clear();
	  Thread.sleep(2000);
	  RegistrationRepo.entermobilenumber(driver).clear();
	  Thread.sleep(2000);
	  }  
      }
 

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
