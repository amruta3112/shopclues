package Profile;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.ProfileRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class ProfileUpdate 
{
	WebDriver driver;
  @BeforeTest
  public void beforeTest() throws InterruptedException 
  {
	     WebDriverManager.chromedriver().setup();
		 driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 Thread.sleep(2000);
  }
  @Test
  public void f() throws IOException, InterruptedException 
  {
	  FileInputStream file=new   FileInputStream("data//profileupdate.xlsx");
	  XSSFWorkbook w=new  XSSFWorkbook(file);
	  XSSFSheet s=w.getSheet("profile");
	  int rowsize=s.getLastRowNum();
	  System.out.println("no of firstname:"+rowsize);
	  System.out.println("no of lastname:"+rowsize);
	  System.out.println("no of mobileno:"+rowsize);
	  System.out.println("no of email:"+rowsize);
	  
	  ProfileRepo p=new ProfileRepo();
	  
	  ProfileRepo.url(driver);
	  Thread.sleep(3000);
	  ProfileRepo.clickonsignin(driver).click();
	  Thread.sleep(3000);
	  ProfileRepo.enteremailid(driver);
	  Thread.sleep(4000);
	  ProfileRepo.clickonLoginviaOTP(driver).click();
	  Thread.sleep(20000);
	  ProfileRepo.clickonverify(driver).click();
	  Thread.sleep(5000);
	  ProfileRepo.clickonHipatilamr(driver).click();
	  Thread.sleep(4000);
	  ProfileRepo.clickonmyprofile(driver).click();
	  Thread.sleep(4000);
	  
	  for(int i=1; i<=rowsize; i++)
	  {
		  String firstname=s.getRow(i).getCell(0).getStringCellValue();
		  String lastname=s.getRow(i).getCell(1).getStringCellValue();
		  String mobileno=s.getRow(i).getCell(2).getStringCellValue();
		  String email=s.getRow(i).getCell(3).getStringCellValue();
		  
		  
			 ProfileRepo.firstname(driver).clear();
			  
			 ProfileRepo.lastname(driver).clear();
			 
			 ProfileRepo.mobileno(driver).clear();
	
  
	 ProfileRepo.firstname(driver).sendKeys(firstname);
	 Thread.sleep(3000);
	 ProfileRepo.lastname(driver).sendKeys(lastname);
	 Thread.sleep(3000);
	 ProfileRepo.mobileno(driver).sendKeys(mobileno);
	 Thread.sleep(3000);
	 
	 JavascriptExecutor js=(JavascriptExecutor) driver;
	  js.executeScript("window.scrollBy(0,500)");
	  
	
	  js.executeScript("arguments[0].click();", ProfileRepo.female(driver));
	  Thread.sleep(3000);
	  ProfileRepo.clickonupdateprofile(driver).click();
	  Thread.sleep(3000);
	  
	 
	  }
		
	}
  
  

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
