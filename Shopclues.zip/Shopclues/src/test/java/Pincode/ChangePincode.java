package Pincode;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.PincodeRepo;
import repository.ProfileRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class ChangePincode 
{
	WebDriver driver;
  @BeforeTest
   public void beforeTest() throws InterruptedException
   {
	     WebDriverManager.chromedriver().setup();
		 driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 Thread.sleep(2000);
   }
  @Test
  public void f() throws IOException, InterruptedException 
  {
	  FileInputStream file=new   FileInputStream("data//pincode.xlsx");
	  XSSFWorkbook w=new  XSSFWorkbook(file);
	  XSSFSheet s=w.getSheet("pincode1");
	  int rowsize=s.getLastRowNum();
	  System.out.println("no of pincode:"+rowsize);
	  PincodeRepo pn=new PincodeRepo();
	  
	  PincodeRepo.url(driver);
	  Thread.sleep(3000);
	  PincodeRepo.clickonsharelocation(driver).click();
	  Thread.sleep(3000);
	  
	  
	  for(int i=1; i<=rowsize; i++)
	  {
		  String pincode=s.getRow(i).getCell(0).getStringCellValue();
		  
		  PincodeRepo.enterpincode(driver).sendKeys(pincode);
		  Thread.sleep(3000);
		  PincodeRepo.clickonsubmit(driver).click();
		  Thread.sleep(3000);
		 
		 PincodeRepo.enterpincode(driver).clear();
		 Thread.sleep(2000);
		  
	  }
	 
	  
	  
	  
	  
  }
  
  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
