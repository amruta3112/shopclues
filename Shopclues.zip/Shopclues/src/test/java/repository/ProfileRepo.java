package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ProfileRepo 
{
	static WebElement element;
	public static void url(WebDriver driver) throws InterruptedException
	{
		driver.get("https://bazaar.shopclues.com/");
	}
	public static WebElement  clickonsignin(WebDriver driver)
	{
		element=driver.findElement(By.linkText("Sign In"));
		return element;
	}
	public static void enteremailid(WebDriver driver)
	{
		 driver.findElement(By.name("user_login")).sendKeys("patilamrii31@gmail.com");
		
	}
	public static WebElement  clickonLoginviaOTP(WebDriver driver)
	{
		element=driver.findElement(By.linkText("Login via OTP"));
		return element;
	}
	public static WebElement  clickonverify(WebDriver driver)
	{
		element=driver.findElement(By.linkText("Verify"));
		return element;
	}
	public static WebElement  clickonHipatilamr(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"sc_uname\"]/a"));
		return element;
	}
	public static WebElement  clickonmyprofile(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"sc_uname\"]/div/ul/li[4]/a"));
		return element;
	}
	public static WebElement  firstname(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"firstname\"]"));
		return element;
	}
	public static WebElement lastname(WebDriver driver)
	{
		element=driver.findElement(By.id("lastname"));
		return element;
	}
	public static WebElement  mobileno(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"phone\"]"));
		return element;
	}
	public static WebElement email(WebDriver driver)
	{
		element=driver.findElement(By.id("email"));
		return element;
	}
	public static WebElement female(WebDriver driver)
	{
		element=driver.findElement(By.id("gnd-radio-1-2"));
		return element;
	}
	
	public static WebElement  clickonupdateprofile(WebDriver driver)
	{
		element=driver.findElement(By.id("save_profile_but"));
		return element;
	}

}
