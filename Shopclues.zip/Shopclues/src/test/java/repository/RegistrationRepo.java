package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegistrationRepo
{
	static WebElement element;
	
	public static void url(WebDriver driver)
	{
		driver.get("https://login.shopclues.com/registration");
	}
	public static WebElement  clickonRegister(WebDriver driver)
	{
		element=driver.findElement(By.linkText("REGISTER"));
		return element;
	}
	public static WebElement enteremailid(WebDriver driver)
	{
		element= driver.findElement(By.name("email"));
		return element;
		
	}
	public static WebElement entermobilenumber(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"register\"]/form/fieldset/div[3]/input"));
		return element;
	}
	public static WebElement clickonregisterbutton(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"register\"]/form/fieldset/div[6]/div/a"));
		return element;
	}
	
	

}
