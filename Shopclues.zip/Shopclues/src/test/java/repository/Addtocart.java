package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Addtocart 
{
	static WebElement element;
	public static void url(WebDriver driver) throws InterruptedException
	{
		driver.get("https://bazaar.shopclues.com/");
		
	}
	public static void  search(WebDriver driver) throws InterruptedException
	{
	    driver.findElement(By.xpath("//*[@id=\"autocomplete\"]")).sendKeys("handbags");
	   
	}
	public static void clickonsearch (WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.linkText("Search")).click();
		
	}
	public static void clickonproduct (WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"det_img_148824320\"]")).click();
	}
	
	
	public static void clickonselectcolour (WebDriver driver)
	
	{
		driver.findElement(By.xpath("//*[@id=\"4172022\"]/span")).click();
	}
	
	public static void clickonAddtocart (WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"add_cart\"]")).click();
	}
	public static void clickonviewcart (WebDriver driver)
	{
		driver.findElement(By.xpath("/html/body/div[3]/div/div/div[4]/ul/li[4]/a/span")).click();
	}
	public static void clickonPlaceorder (WebDriver driver)
	{
		driver.findElement(By.linkText("Place Order")).click();
	}
	public static void enteremail (WebDriver driver)
	{
		driver.findElement(By.id("main_user_login")).sendKeys("patilamrii31@gmail.com");
	}
	public static void clickonloginviaotp (WebDriver driver)
	{
		driver.findElement(By.linkText("Login via OTP")).click();
	}
	public static void  clickonverify(WebDriver driver)
	{
        driver.findElement(By.linkText("Verify")).click();
	}
	public static void clickonchange (WebDriver driver)
	{
		driver.findElement(By.linkText("Change")).click();
	}
	public static void clickonnewaddress (WebDriver driver)
	{
		driver.findElement(By.linkText("New Address")).click();
	}
	public static WebElement pincode (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"s_zipcode\"]"));
		return element;
	}
	public static WebElement city (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"s_city\"]"));
		return element;
	}
	public static WebElement state (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"s_state\"]"));
		return element;
	}
	public static WebElement name (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"s_firstname\"]"));
		return element;
		
	}
	public static WebElement phoneNo (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"s_phone\"]"));
		return element;
		
	}
	public static WebElement houseNo (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"s_address\"]"));
		return element;
	}
	public static WebElement Area (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"s_address_2\"]"));
		return element;
	}
	
	public static void Clickoncontinue (WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"submit_btn\"]/span/input")).click();
		
	}
	
	
	

	

}
