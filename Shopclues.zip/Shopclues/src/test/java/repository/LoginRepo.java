package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginRepo
{
static WebElement element;
	
	public static void url(WebDriver driver)
	{
		driver.get("https://login.shopclues.com/registration");
	}
	public static WebElement  clickonLogin(WebDriver driver)
	{
		element=driver.findElement(By.linkText("LOGIN"));
		return element;
	}
	public static WebElement enteremailid(WebDriver driver)
	{
		element= driver.findElement(By.name("user_login"));
		return element;
	}
	public static WebElement  clickonLoginviaOTP(WebDriver driver)
	{
		element=driver.findElement(By.linkText("Login via OTP"));
		return element;
	}
	
	public static WebElement  clickonverify(WebDriver driver)
	{
		element=driver.findElement(By.linkText("Verify"));
		return element;
	}
	
	public static WebElement  clickonHipatilamr(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"sc_uname\"]/a"));
		return element;
	}
	
	public static WebElement  clickonsignout(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"sc_uname\"]/div/ul/li[11]/a"));
		return element;
	}
	
	public static WebElement  clickonsignin(WebDriver driver)
	{
		element=driver.findElement(By.linkText("Sign In"));
		return element;
	}
	
	
}
