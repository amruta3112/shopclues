package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PaymentRepo 
{
	static WebElement element;
	public static void url(WebDriver driver) throws InterruptedException
	{
		driver.get("https://bazaar.shopclues.com/?__ar=Y");
		
	}
	public static void  search(WebDriver driver) throws InterruptedException
	{
	    driver.findElement(By.xpath("//*[@id=\"autocomplete\"]")).sendKeys("handbags");
	   
	}
	public static void clickonsearch (WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.linkText("Search")).click();
		
	}
	public static void clickonproduct (WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"det_img_148824320\"]")).click();
	}
	
	
	public static void clickonselectcolour (WebDriver driver)
	
	{
		driver.findElement(By.xpath("//*[@id=\"4172022\"]/span")).click();
	}
	
	public static void clickonAddtocart (WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"add_cart\"]")).click();
	}
	public static void clickonviewcart (WebDriver driver)
	{
		driver.findElement(By.xpath("/html/body/div[3]/div/div/div[4]/ul/li[4]/a/span")).click();
	}
	public static void clickonPlaceorder (WebDriver driver)
	{
		driver.findElement(By.linkText("Place Order")).click();
    }
	public static void enteremail (WebDriver driver)
	{
		driver.findElement(By.id("main_user_login")).sendKeys("patilamrii31@gmail.com");
	}
	public static void clickonloginviaotp (WebDriver driver)
	{
		driver.findElement(By.linkText("Login via OTP")).click();
	}
	public static void  clickonverify(WebDriver driver)
	{
        driver.findElement(By.linkText("Verify")).click();
    }
	public static void  clickonproceedtopay(WebDriver driver)
	{
        driver.findElement(By.xpath("//*[@id=\"proceed_to_payment_button\"]")).click();
    }
	
	public static WebElement formFrame(WebDriver driver)
	{
		element= driver.findElement(By.xpath("/html/body/div[5]/div[2]/div/div/div[2]/div/div[1]/div[2]/div[2]/div/iframe"));
		return element;
	}
	public static WebElement  clickoncardNo(WebDriver driver)
	{
        element=driver.findElement(By.id("cc_number"));
        return element;
	}
 
	public static WebElement  clickonmonth(WebDriver driver)
	{
        element=driver.findElement(By.xpath("/html/body/div[3]/div[2]/form/div[2]/div[3]/div[1]/input[1]"));
        return element;
    }
	public static WebElement  clickonyear(WebDriver driver)
	{
        element=driver.findElement(By.xpath("/html/body/div[3]/div[2]/form/div[2]/div[3]/div[1]/input[2]"));
        return element;
    }
	public static WebElement  clickoncvv(WebDriver driver)
	{
        element=driver.findElement(By.xpath("/html/body/div[3]/div[2]/form/div[2]/div[3]/div[2]/input"));
        return element;
    }
	public static WebElement  clickonname(WebDriver driver)
	{
        element=driver.findElement(By.xpath("/html/body/div[3]/div[2]/form/div[2]/div[4]/input"));
        return element;
    }
	public static WebElement  clickonnickname(WebDriver driver)
	{
        element=driver.findElement(By.xpath("/html/body/div[3]/div[2]/form/div[2]/div[5]/input"));
        return element;
    }
	public static void  clickonpay(WebDriver driver)
	{
        driver.findElement(By.xpath("//*[@id=\"add-card-pay-btn\"]")).click();
    }
}
