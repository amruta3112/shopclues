package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PincodeRepo
{
	static WebElement element;
	public static void url(WebDriver driver) throws InterruptedException
	{
		driver.get("https://bazaar.shopclues.com/?__ar=Y");
	}
	public static WebElement  clickonsharelocation(WebDriver driver)
	{
		element=driver.findElement(By.linkText("Location"));
		return element;
	}
	public static WebElement  enterpincode(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"pin_code_popup\"]"));
		return element;
	}
	public static WebElement  clickonsubmit(WebDriver driver)
	{
		element=driver.findElement(By.id("get_pincode_popup"));
		return element;
	}

}
