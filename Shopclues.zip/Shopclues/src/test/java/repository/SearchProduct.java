package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchProduct 
{
	
	public static void url(WebDriver driver) throws InterruptedException
	{
		driver.get("https://bazaar.shopclues.com/");
		
	}
	public static void  search(WebDriver driver) throws InterruptedException
	{
	    driver.findElement(By.xpath("//*[@id=\"autocomplete\"]")).sendKeys("handbags");
	   
	}
	public static void clickonsearch (WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.linkText("Search")).click();
		
	}
}
