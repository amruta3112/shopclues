package cart;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.Addtocart;
import repository.LoginRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class AddToCart 
{
	WebDriver driver;
 @BeforeTest
  public void beforeTest() throws InterruptedException
 {

     WebDriverManager.chromedriver().setup();
	 driver=new ChromeDriver();
	 driver.manage().window().maximize();
	 Thread.sleep(2000);
 }
  @Test
  public void f() throws InterruptedException, IOException 
  {
	  FileInputStream file=new   FileInputStream("data/Address.xlsx");
	  XSSFWorkbook w=new  XSSFWorkbook(file);
	  XSSFSheet s=w.getSheet("Sheet1");
	  int rowsize=s.getLastRowNum();
	  System.out.println("no of pincode:"+rowsize);
	  System.out.println("no of city:"+rowsize);
	  System.out.println("no of state:"+rowsize);
	  System.out.println("no of name:"+rowsize);
	  System.out.println("no of phoneNo:"+rowsize);
	  System.out.println("no of houseNo:"+rowsize);
	  System.out.println("no of Area:"+rowsize);
	  
	  
	 Addtocart a=new Addtocart();
	 
	  Addtocart.url(driver);
	  Addtocart.search(driver);
	  Thread.sleep(4000);
	  Addtocart.clickonsearch(driver);
	  Thread.sleep(3000);
	
	  driver.getWindowHandles();
	  String parentWin=driver.getWindowHandle();
	  
	  Addtocart.clickonproduct(driver);
	  Thread.sleep(3000);
	 
	  
	  for(String wins : driver.getWindowHandles())
	  {
		  driver.switchTo().window(wins);
	  }
	  JavascriptExecutor js=(JavascriptExecutor) driver;
	  js.executeScript("window.scrollBy(0,500)");
		
	  Thread.sleep(4000);
	  Addtocart.clickonselectcolour(driver);
	  Thread.sleep(2000);
	  Addtocart.clickonAddtocart(driver);
	  Thread.sleep(3000);
	  Addtocart.clickonviewcart(driver);
	  Thread.sleep(4000);
	  Addtocart.clickonPlaceorder(driver);
	  Thread.sleep(3000);
	  Addtocart.enteremail(driver);
	  Thread.sleep(3000);
	  Addtocart.clickonloginviaotp(driver);
	  Thread.sleep(20000);
	  Addtocart.clickonverify(driver);
	  Thread.sleep(5000);
	  Addtocart.clickonchange(driver);
	  Thread.sleep(3000);
	 
	  
	  
	  for(int i=1; i<=rowsize; i++)
	  {
		  String pincode=s.getRow(i).getCell(0).getStringCellValue();
		  String city=s.getRow(i).getCell(1).getStringCellValue();
		  String state=s.getRow(i).getCell(2).getStringCellValue();
		  String name=s.getRow(i).getCell(3).getStringCellValue();
		  String phoneNo=s.getRow(i).getCell(4).getStringCellValue();
		  String houseNo=s.getRow(i).getCell(5).getStringCellValue();
		  String Area=s.getRow(i).getCell(6).getStringCellValue();
		  
		  System.out.println(pincode + " , "+ city +" , "+ state+ " , "+ name+ " , "+phoneNo+ " , "+houseNo+ " , "+Area);
	  
	
	  
	  Addtocart.clickonnewaddress(driver);
	  Thread.sleep(4000);
	  Addtocart.pincode(driver).sendKeys(pincode);
	  Thread.sleep(6000);
	  Addtocart.city(driver).sendKeys(city);
	  Thread.sleep(6000);
	  Addtocart.state(driver).sendKeys(state);
	  Thread.sleep(6000);
	  Addtocart.name(driver).sendKeys(name);
	  Thread.sleep(6000);
	  Addtocart.phoneNo(driver).sendKeys(phoneNo);
	  Thread.sleep(6000);
	  Addtocart.houseNo(driver).sendKeys(houseNo);
	  Thread.sleep(6000);
	  Addtocart.Area(driver).sendKeys(Area);
	  Thread.sleep(4000);
	  Addtocart.Clickoncontinue(driver);
	  Thread.sleep(8000);
	  
	  if(driver.getTitle().equals("Review Page"))
	  {
		  driver.navigate().back();
		  
		  System.out.println("valid data");
	      System.out.println("");
	  }
	  else 
	  {
		  System.out.println("invalid data");
	      System.out.println("");
		  driver.findElement(By.id("fdclose")).click();
	  }
		  
	 
	  }
      
	  }
  

  @AfterTest
  public void afterTest() 
  {
	  driver.quit();
  }

}
