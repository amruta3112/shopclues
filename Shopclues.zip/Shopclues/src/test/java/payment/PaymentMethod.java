package payment;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.PaymentRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class PaymentMethod 
{
	WebDriver driver;
  @BeforeTest
  public void beforeTest() throws InterruptedException 
  {

	     WebDriverManager.chromedriver().setup();
		 driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 Thread.sleep(2000);
  }
  @Test
  public void f() throws InterruptedException, IOException 
  {
	  FileInputStream file=new   FileInputStream("data/Address.xlsx");
	  XSSFWorkbook w=new  XSSFWorkbook(file);
	  XSSFSheet s=w.getSheet("Pay");
	  int rowsize=s.getLastRowNum();
	  System.out.println("no of cardNo:"+rowsize);
	  System.out.println("no of month:"+rowsize);
	  System.out.println("no of year:"+rowsize);
	  System.out.println("no of cvv:"+rowsize);
	  System.out.println("no of name:"+rowsize);
	  System.out.println("no of nickname:"+rowsize);
	  
	  
	  
	  PaymentRepo p= new PaymentRepo();
	  PaymentRepo.url(driver);
	  Thread.sleep(3000);
	  PaymentRepo.search(driver);
	  Thread.sleep(3000);
	  PaymentRepo.clickonsearch(driver);
	  Thread.sleep(3000);
	  PaymentRepo.clickonproduct(driver);
	  Thread.sleep(3000);
	  for(String wins : driver.getWindowHandles())
	  {
		  driver.switchTo().window(wins);
	  }
	  JavascriptExecutor js=(JavascriptExecutor) driver;
	  js.executeScript("window.scrollBy(0,500)");
		
	  Thread.sleep(4000);
	  PaymentRepo.clickonselectcolour(driver);
	  Thread.sleep(3000);
	  PaymentRepo.clickonAddtocart(driver);
	  Thread.sleep(3000);
	  PaymentRepo.clickonviewcart(driver);
	  Thread.sleep(3000);
	  PaymentRepo.clickonPlaceorder(driver);
	  Thread.sleep(3000);
	  PaymentRepo.enteremail(driver);
	  Thread.sleep(4000);
	  PaymentRepo.clickonloginviaotp(driver);
	  Thread.sleep(20000);
	  PaymentRepo.clickonverify(driver);
	  Thread.sleep(4000);
	  PaymentRepo.clickonproceedtopay(driver);
	  Thread.sleep(4000);
	  
	  driver.switchTo().frame(PaymentRepo.formFrame(driver));
	  
	  for(int i=1; i<=rowsize; i++)
	  {
		  String cardNo=s.getRow(i).getCell(0).getStringCellValue();
		  String month =s.getRow(i).getCell(1).getStringCellValue();
		  String year=s.getRow(i).getCell(2).getStringCellValue();
		  String cvv=s.getRow(i).getCell(3).getStringCellValue();
		  String name=s.getRow(i).getCell(4).getStringCellValue();
		  String nickname=s.getRow(i).getCell(5).getStringCellValue();
		  
		  PaymentRepo.clickoncardNo(driver).sendKeys(cardNo);
		  Thread.sleep(4000);
		  PaymentRepo.clickonmonth(driver).sendKeys(month);
		  Thread.sleep(4000);
		  PaymentRepo.clickonyear(driver).sendKeys(year);
		  Thread.sleep(4000);
		  PaymentRepo.clickoncvv(driver).sendKeys(cvv);
		  Thread.sleep(4000);
		  PaymentRepo.clickonname(driver).sendKeys(name);
		  Thread.sleep(4000);
		  PaymentRepo.clickonnickname(driver).sendKeys(nickname);
		  Thread.sleep(4000);
		  PaymentRepo.clickonpay(driver);
		  Thread.sleep(4000);
		  
		  if(driver.getTitle().equals("Checkout"))
		  {
			  PaymentRepo.clickoncardNo(driver).clear();
			  
			  PaymentRepo.clickonmonth(driver).clear();
			  
			  PaymentRepo.clickonyear(driver).clear();
			  
			  PaymentRepo.clickoncvv(driver).clear();
			  
			  PaymentRepo.clickonname(driver).clear();
			  
			  PaymentRepo.clickonnickname(driver).clear();
			  
		  }
		
	  }
	   
  }
 

  @AfterTest
  public void afterTest()
  {
	  driver.quit();
  }

}
