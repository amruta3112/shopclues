package login;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.LoginRepo;
import repository.RegistrationRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class LoginTest 
{
	WebDriver driver;

	
  @BeforeTest
   public void beforeTest() throws InterruptedException, IOException
   {

		 WebDriverManager.chromedriver().setup();
		 driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 Thread.sleep(2000);
		
	 }
   
  @Test
  public void Login() throws InterruptedException, IOException
  {
	  FileInputStream file=new   FileInputStream("data\\Login.xlsx");
	  XSSFWorkbook w=new  XSSFWorkbook(file);
	  XSSFSheet s=w.getSheet("LoginEx");
	  int rowsize=s.getLastRowNum();
	  System.out.println("no of email id:"+rowsize);
	  LoginRepo l=new  LoginRepo();
	  
	  LoginRepo.url(driver);
	  
	  for(int i=1; i<=rowsize; i++)
	  {
		  String emailid=s.getRow(i).getCell(0).getStringCellValue();
		try
		{
		  System.out.println(emailid);
		  LoginRepo.clickonLogin(driver).click();
	      Thread.sleep(2000);
	      LoginRepo.enteremailid(driver).sendKeys(emailid);
	      Thread.sleep(3000);
	      LoginRepo.clickonLoginviaOTP(driver).click();
	      Thread.sleep(22000);
	      LoginRepo.clickonverify(driver).click();
	      Thread.sleep(15000);
	      LoginRepo.clickonHipatilamr(driver).click();
	      Thread.sleep(3000);
	      LoginRepo.clickonsignout(driver).click();
	      Thread.sleep(5000);
	      LoginRepo.clickonsignin(driver).click();
	      Thread.sleep(3000);
	      System.out.println("valid data");
	      System.out.println("");
	   }
	      
	  
	      catch(Exception e)
	      {
	    	 LoginRepo.enteremailid(driver).clear();
	    	 System.out.println("invalid data");
	    	 System.out.println("");
	      }
	    	  
	  }
	  
  }

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
